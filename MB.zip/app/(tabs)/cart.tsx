import Header from '@/components/Header';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Image, SafeAreaView, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const initialCartItems = [
    {
        id: 1,
        name: 'Áo 3 LỖ Nữ Thun Ríp Cơ Bản - Xanh cốm - M',
        variant: 'Xanh cốm, M',
        price: 49000,
        quantity: 1,
        image: 'https://buggy.yodycdn.com/images/product/04d5a4cd850fc59d3410645893014721.webp', // <-- THAY BẰNG ĐƯỜNG DẪN ẢNH CỦA BẠN
        selected: true,
    },
    {
        id: 2,
        name: 'Áo Polo Lá Cổ Công Nghệ Không Đường May - TRẮNG 006 - M',
        variant: 'TRẮNG 006, M',
        price: 369000,
        quantity: 1,
        image: 'https://buggy.yodycdn.com/images/product/11f66e245e60c96d001ab6b2a1f60e8b.webp', // <-- THAY BẰNG ĐƯỜNG DẪN ẢNH CỦA BẠN
        selected: true,
    },
];


const formatCurrency = (amount: any) => {
    return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + 'đ';
};

export default function CartScreen() {
    const [items, setItems] = useState(initialCartItems);
    const [selectAll, setSelectAll] = useState(true);
    
    const totalPrice = items.reduce((sum, item) => {
        return item.selected ? sum + item.price * item.quantity : sum;
    }, 0);

    return (
        <SafeAreaView style={styles.container}>
            <Header/>
            
            <View>
                <Text style={styles.titlepage}>Giỏ hàng</Text>
            </View>

            <ScrollView contentContainerStyle={styles.scrollViewContent}>
                {/* Phần Chọn tất cả */}
                <View style={styles.selectAllContainer}>
                    <TouchableOpacity onPress={() => setSelectAll(!selectAll)}>
                        <Ionicons 
                            name={selectAll ? "checkbox" : "square-outline"} 
                            size={24} 
                            color="#f5b301" 
                        />
                    </TouchableOpacity>
                    <Text style={styles.selectAllText}>Chọn tất cả</Text>
                </View>

                {/* Danh sách sản phẩm */}
                {items.map((item, index) => (
                    <View key={item.id} style={styles.productItemContainer}>
                        {/* Checkbox chọn sản phẩm */}
                        <TouchableOpacity style={styles.checkbox}>
                             <Ionicons 
                                name={item.selected ? "checkbox" : "square-outline"} 
                                size={24} 
                                color="#f5b301" 
                            />
                        </TouchableOpacity>

                        {/* Hình ảnh sản phẩm */}
                        <Image source={{ uri: item.image }} style={styles.productImage} />


                        {/* Thông tin chi tiết sản phẩm */}
                        <View style={styles.productDetails}>
                            <View style={styles.productNameRow}>
                                <Text style={styles.productName}>{item.name}</Text>
                                <TouchableOpacity>
                                    <Ionicons name="trash-outline" size={20} color="#888" />
                                </TouchableOpacity>
                            </View>

                            <View style={styles.variantContainer}>
                                <Text style={styles.variantText}>{item.variant} ▾</Text>
                            </View>

                            <View style={styles.priceQuantityRow}>
                                <View style={styles.quantitySelector}>
                                    <TouchableOpacity style={styles.quantityButton}>
                                        <Text style={styles.quantityButtonText}>-</Text>
                                    </TouchableOpacity>
                                    <Text style={styles.quantityText}>{item.quantity}</Text>
                                    <TouchableOpacity style={styles.quantityButton}>
                                        <Text style={styles.quantityButtonText}>+</Text>
                                    </TouchableOpacity>
                                </View>
                                <Text style={styles.productPrice}>{formatCurrency(item.price)}</Text>
                            </View>
                        </View>
                    </View>
                    
                ))}
            </ScrollView>

            {/* Phần footer tổng tiền và đặt hàng */}
            <View style={styles.footer}>
                <View style={styles.shippingInfo}>
                     <FontAwesome name="truck" size={16} color="#555" />
                     <Text style={styles.shippingText}>Đơn từ 498k được miễn phí vận chuyển nhé!</Text>
                </View>
                <View style={styles.checkoutContainer}>
                    <View>
                        <Text style={styles.totalLabel}>Tổng {formatCurrency(totalPrice)}</Text>
                        <Text style={styles.subLabel}>Mua nhiều giảm nhiều</Text>
                    </View>
                    <TouchableOpacity style={styles.orderButton}>
                        <Text style={styles.orderButtonText}>Đặt hàng</Text>
                        <FontAwesome name="arrow-right" size={16} color="black" />
                    </TouchableOpacity>
                </View>
            </View>
            
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    titlepage: {
        textAlign: 'center',
        fontSize: 18,
        fontWeight: '600',
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#f0f0f0'
    },
    scrollViewContent: {
        paddingBottom: 150, // Thêm khoảng đệm để không bị footer che mất
    },
    selectAllContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 12,
    },
    selectAllText: {
        marginLeft: 8,
        fontSize: 16,
    },
    productItemContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingVertical: 12,
        alignItems: 'flex-start',
    },
    checkbox: {
        marginRight: 10,
        marginTop: 20, // Căn chỉnh checkbox cho phù hợp
    },
    productImage: {
        width: 80,
        height: 100,
        borderRadius: 8,
        marginRight: 12,
    },
    productDetails: {
        flex: 1,
    },
    productNameRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
    },
    productName: {
        fontSize: 14,
        fontWeight: '500',
        flex: 1, // Để text tự xuống dòng
        marginRight: 8,
    },
    variantContainer: {
        backgroundColor: '#f5f5f5',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 4,
        alignSelf: 'flex-start',
        marginVertical: 8,
    },
    variantText: {
        fontSize: 12,
        color: '#555',
    },
    priceQuantityRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 8,
    },
    quantitySelector: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#e0e0e0',
        borderRadius: 6,
    },
    quantityButton: {
        paddingHorizontal: 12,
        paddingVertical: 4,
    },
    quantityButtonText: {
        fontSize: 18,
        color: '#555',
    },
    quantityText: {
        paddingHorizontal: 12,
        fontSize: 16,
        fontWeight: '600',
    },
    productPrice: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    footer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        borderTopWidth: 1,
        borderTopColor: '#f0f0f0',
        paddingHorizontal: 16,
        paddingVertical: 12,
        paddingBottom: 24, // Thêm padding cho các thiết bị có tai thỏ
    },
    shippingInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    shippingText: {
        marginLeft: 8,
        fontSize: 12,
        color: '#555',
    },
    checkoutContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    totalLabel: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    subLabel: {
        fontSize: 12,
        color: '#888',
    },
    orderButton: {
        backgroundColor: '#ffd700',
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 20,
        flexDirection: 'row',
        alignItems: 'center',
    },
    orderButtonText: {
        fontSize: 16,
        fontWeight: 'bold',
        marginRight: 8,
    },
});