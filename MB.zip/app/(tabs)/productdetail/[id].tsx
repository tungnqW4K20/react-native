// THÊM VÀO: hook để lấy tham số từ URL
import Header from '@/components/Header';
import ProductDetails from '@/components/ProductDetails'; // Giả định bạn đã có component này
import ProductGallery from '@/components/ProductGallery';
import ProductInfoSections from '@/components/ProductInfoSections';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';

// Interfaces for API data (giữ nguyên)
interface ApiColorOption {
  id: number;
  name: string;
  price: string;
  image_urls: string[];
  colorCode: string | null;
}

interface ApiSizeOption {
  id: number;
  name: string;
  price: string | null;
}

interface Product {
  id: number;
  name: string;
  description: string;
  price: string;
  image_url: string;
  colorOptions: ApiColorOption[];
  sizeOptions: ApiSizeOption[];
}

// Helper to format price (giữ nguyên)
const formatPrice = (priceString: string) => {
    const price = parseFloat(priceString);
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(price);
};

export default function ProductDetailScreen() {
  // THÊM VÀO: Lấy `id` từ URL. ví dụ: /product/4 -> id = "4"
  const { id } = useLocalSearchParams<{ id: string }>();

  const [loading, setLoading] = useState(true);
  const [product, setProduct] = useState<Product | null>(null);
  const [selectedColor, setSelectedColor] = useState<ApiColorOption | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Chỉ chạy khi có `id`
    if (!id) {
        setLoading(false);
        setError("Không tìm thấy ID sản phẩm.");
        return;
    };

    const fetchProductDetails = async () => {
      setLoading(true);
      setError(null);
      try {
        // SỬA ĐỔI: Sử dụng `id` để gọi đúng API
        const response = await fetch(`http://172.20.10.3:3000/api/products/${id}/details`);
        const result = await response.json();
        
        if (result.success) {
          const productData = result.data;
          
          // SỬA LỖI QUAN TRỌNG: Thay thế 'localhost' bằng địa chỉ IP
          // để ảnh có thể hiển thị trên thiết bị di động/máy ảo.
          const fixUrl = (url: string) => url.replace('localhost', '172.20.10.3');
          
          productData.image_url = fixUrl(productData.image_url);
          productData.colorOptions.forEach((color: ApiColorOption) => {
            color.image_urls = color.image_urls.map(fixUrl);
          });

          setProduct(productData);
          // Mặc định chọn màu đầu tiên trong danh sách
          if (productData.colorOptions && productData.colorOptions.length > 0) {
            setSelectedColor(productData.colorOptions[0]);
          }
        } else {
          setError('Không thể tải dữ liệu sản phẩm.');
        }
      } catch (e) {
        console.error("Lỗi khi fetch chi tiết sản phẩm:", e);
        setError('Đã có lỗi mạng xảy ra.');
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [id]); // SỬA ĐỔI: useEffect sẽ chạy lại mỗi khi `id` thay đổi
   
  const handleAddToCart = (details: { color: ApiColorOption; size: string; quantity: number }) => {
    console.log('Sản phẩm đã được thêm vào giỏ:', {
      productId: product?.id,
      productName: product?.name,
      ...details,
    });
    // TODO: Thêm logic xử lý thêm vào giỏ hàng thực tế
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2c3e50" />
      </View>
    );
  }

  if (error || !product) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <Header />
        <View style={styles.centered}>
          <Text>{error || 'Không tìm thấy sản phẩm.'}</Text>
        </View>
      </SafeAreaView>
    );
  }

  // Dữ liệu đã sẵn sàng, truyền xuống các component con để hiển thị
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView>
        <Header/>

        <ProductGallery images={selectedColor?.image_urls || [product.image_url]} />

        <ProductDetails
          name={product.name}
          price={formatPrice(product.price)}
          code={`SKU-${product.id}`}
          colors={product.colorOptions}
          sizes={product.sizeOptions.map(s => s.name)}
          selectedColor={selectedColor!}
          initialSize={product.sizeOptions[0]?.name || ''}
          onColorChange={setSelectedColor}
          onAddToCart={handleAddToCart}
        />

        <ProductInfoSections description={product.description} />
        
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

