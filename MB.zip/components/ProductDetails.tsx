// components/product/ProductDetails.tsx
import React, { useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

// Sử dụng lại interface đầy đủ từ API để đảm bảo tương thích
interface ApiColorOption {
  id: number;
  name: string;
  price: string;
  image_urls: string[];
  colorCode: string | null;
}

// Cập nhật Props để sử dụng ApiColorOption
interface Props {
  name: string;
  price: string;
  code: string;
  colors: ApiColorOption[];
  sizes: string[];
  selectedColor: ApiColorOption;
  initialSize: string;
  onColorChange: (color: ApiColorOption) => void;
  onAddToCart: (details: { color: ApiColorOption; size: string; quantity: number }) => void;
}

const ProductDetails: React.FC<Props> = ({ name, price, code, colors, sizes, selectedColor, initialSize, onColorChange, onAddToCart }) => {
  const [selectedSize, setSelectedSize] = useState<string>(initialSize);
  const [quantity, setQuantity] = useState(1);

  const handleDecreaseQuantity = () => setQuantity(q => Math.max(1, q - 1));
  const handleIncreaseQuantity = () => setQuantity(q => q + 1);

  const handleAddToCartPress = () => {
    onAddToCart({
      color: selectedColor,
      size: selectedSize,
      quantity,
    });
  };

  return (
    <View style={styles.container}>
      {/* Product Info */}
      <Text style={styles.price}>{price}</Text>
      <Text style={styles.productName}>{name}</Text>
      <Text style={styles.productCode}>{code}</Text>

      {/* Color Selector */}
      <Text style={styles.label}>Màu sắc: {selectedColor.name}</Text>
      <View style={styles.selectorContainer}>
        {colors.map((color) => (
          <TouchableOpacity
            key={color.id}
            style={[styles.colorOuterCircle, selectedColor.id === color.id && styles.selectedColor]}
            onPress={() => onColorChange(color)}
          >
            <View style={[styles.colorInnerCircle, { backgroundColor: color.colorCode || '#E0E0E0' }]} />
          </TouchableOpacity>
        ))}
      </View>

      {/* Size Selector */}
      <View style={styles.sizeHeader}>
        <Text style={styles.label}>Kích thước: {selectedSize}</Text>
        <TouchableOpacity>
          <Text style={styles.sizeGuide}>Hướng dẫn chọn size</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.selectorContainer}>
        {sizes.map((size) => (
          <TouchableOpacity
            key={size}
            style={[styles.sizeButton, selectedSize === size && styles.selectedSizeButton]}
            onPress={() => setSelectedSize(size)}
          >
            <Text style={[styles.sizeText, selectedSize === size && styles.selectedSizeText]}>{size}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Actions */}
      <View style={styles.actionContainer}>
        <View style={styles.quantitySelector}>
          <TouchableOpacity onPress={handleDecreaseQuantity} style={styles.quantityButton}>
            <Icon name="remove-outline" size={20} color="#000" />
          </TouchableOpacity>
          <Text style={styles.quantityText}>{quantity}</Text>
          <TouchableOpacity onPress={handleIncreaseQuantity} style={styles.quantityButton}>
            <Icon name="add-outline" size={20} color="#000" />
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCartPress}>
          <Text style={styles.addToCartText}>Thêm vào giỏ</Text>
          <Icon name="bag-handle-outline" size={20} color="#333" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
    container: { padding: 15 },
    price: { fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
    productName: { fontSize: 18, marginBottom: 4 },
    productCode: { fontSize: 14, color: '#888', marginBottom: 15 },
    label: { fontSize: 16, fontWeight: '500', marginBottom: 10 },
    selectorContainer: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 15 },
    colorOuterCircle: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginRight: 10, borderWidth: 1, borderColor: '#ddd'},
    selectedColor: { borderColor: '#000' },
    colorInnerCircle: { width: 32, height: 32, borderRadius: 16, borderWidth: 1, borderColor: '#eee'},
    sizeHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    sizeGuide: { color: '#007bff', textDecorationLine: 'underline' },
    sizeButton: { minWidth: 50, height: 40, borderRadius: 8, borderWidth: 1, borderColor: '#ccc', justifyContent: 'center', alignItems: 'center', marginRight: 10, marginBottom: 10, paddingHorizontal: 15},
    selectedSizeButton: { borderColor: '#FFA500', backgroundColor: '#FFF8E1' },
    sizeText: { fontSize: 16 },
    selectedSizeText: { color: '#FFA500', fontWeight: 'bold' },
    actionContainer: { flexDirection: 'row', marginTop: 20 },
    quantitySelector: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ccc', borderRadius: 8, marginRight: 15},
    quantityButton: { padding: 10 },
    quantityText: { fontSize: 18, fontWeight: 'bold', paddingHorizontal: 15 },
    addToCartButton: { flex: 1, flexDirection: 'row', backgroundColor: '#FFD700', justifyContent: 'center', alignItems: 'center', borderRadius: 8},
    addToCartText: { fontSize: 16, fontWeight: 'bold', marginRight: 8, color: '#333' },
});


export default ProductDetails;