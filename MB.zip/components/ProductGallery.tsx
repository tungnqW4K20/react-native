// components/product/ProductGallery.tsx
import React from 'react';
import { Image, StyleSheet, View } from 'react-native';

interface Props {
  images: string[];
}

const ProductGallery: React.FC<Props> = ({ images }) => {
  // Trong tương lai, bạn có thể thay thế View này bằng một FlatList hoặc Swiper để tạo slider ảnh
  if (!images || images.length === 0) {
    return <View style={styles.placeholder} />;
  }

  return (
    <View>
      <Image source={{ uri: images[0] }} style={styles.productImage} />
    </View>
  );
};

const styles = StyleSheet.create({
  productImage: {
    width: '100%',
    height: 450,
    resizeMode: 'cover',
  },
  placeholder: {
    width: '100%',
    height: 450,
    backgroundColor: '#f0f0f0',
  }
});

export default ProductGallery;